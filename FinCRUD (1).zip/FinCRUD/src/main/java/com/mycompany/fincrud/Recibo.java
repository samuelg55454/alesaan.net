/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fincrud;

/**
 *
 * @author Windows
 */
import java.time.LocalDate;
public class Recibo {
    long NIT;
    long ID;
    String proveedor;
    String fecha;
    String hora;
    int cantidad;
    String detalles;

    Recibo(long NIT, long ID, String proveedor, String fecha, String hora, int cantidad,String detalles) {
        this.NIT=NIT;
        this.ID=ID;
        this.proveedor=proveedor;
        this.fecha=fecha;
        this.hora=hora;
        this.cantidad=cantidad;
        this.detalles=detalles;
    }
    public String imprimirDetalles() {
        return String.format(
            "NIT: %d\n" +
            "ID: %d\n" +
            "Proveedor que entregó: %s\n" +
            "Fecha y hora de compra: %s a las %s\n" +
            "Cantidad de artículos comprados: %d\n" +
            "Detalles: %s\n"+
            "-----------\n",
            NIT, ID, proveedor, fecha, hora, cantidad,detalles);
    }
    
}
