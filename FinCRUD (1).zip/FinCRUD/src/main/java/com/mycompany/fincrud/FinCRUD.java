/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.fincrud;

/**
 *
 * @author Windows
 */
public class FinCRUD {

    public static void main(String[] args) {
        front form1 = new front();
        form1.setVisible(true);
    }
}
